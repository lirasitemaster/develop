<?php

$max = '31f';
$break = null;
$print = ['html' => null, 'css' => null];
$arr = [];
for ($i = 0, $a = 0; $a < 16; $a++) {
	for ($b = 0; $b < 16; $b++) {
		for ($c = 0; $c < 16; $c++) {
			$arr[] = dechex($a) . dechex($b) . dechex($c);
			$i++;
			if (
				is_string($max) && $max === dechex($a) . dechex($b) . dechex($c) ||
				is_int($max) && $i >= $max
			) {
				$break = true;
			}
			if (!empty($break)) { break; }
		}
		if (!empty($break)) { break; }
	}
	if (!empty($break)) { break; }
}

$print['css'] .= '/*
  Flaticon icon font by Flaticon
  Creation date: 16/03/2020 11:17
*/

@font-face {
  font-family: "Flaticon";
  src: url("../fonts/Flaticon.eot");
  src: url("../fonts/Flaticon.eot?#iefix") format("embedded-opentype"),
       url("../fonts/Flaticon.woff2") format("woff2"),
       url("../fonts/Flaticon.woff") format("woff"),
       url("../fonts/Flaticon.ttf") format("truetype"),
       url("../fonts/Flaticon.svg#Flaticon") format("svg");
  font-weight: normal;
  font-style: normal;
}

@media screen and (-webkit-min-device-pixel-ratio:0) {
  @font-face {
    font-family: "Flaticon";
    src: url("../fonts/Flaticon.svg#Flaticon") format("svg");
  }
}

[class^="flaticon-"]:before, [class*=" flaticon-"]:before,
[class^="flaticon-"]:after, [class*=" flaticon-"]:after {   
  font-family: Flaticon;
  font-style: normal;
}

.flaticon {
  display: inline-block;
  font: normal normal normal 14px/1 Flaticon;
  font-size: inherit;
  text-rendering: auto;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

/* Glyphs list */
';

$print['html'] .= '<!DOCTYPE html>
<html>
<head>
	<title>Flaticon Webfont</title>
	<link rel="stylesheet" type="text/css" href="../css/flaticon.css">
	<meta charset="UTF-8">
	<style>
		div { display: inline-block; margin: 0.5em; }
		div.break { display: block; border-top: 2px solid #ccc; }
		i.flaticon { padding: 0.25em; background: #eee; font-size: 3em; min-width: 1em; height: 1em; vertical-align: middle; }
		span { display: block; text-align: center; }
	</style>
</head>
<body>
';

foreach ($arr as $item) {
	$print['css'] .= "\r\n" . '.flaticon-' . $item . ':before { content: "\f' . $item . '"; }';
	$print['html'] .= "\r\n" . '  <div>' . "\r\n" . '    <i class="flaticon flaticon-' . $item . '"></i>' . "\r\n" . '    <span>' . $item . '</span>' . "\r\n" . '  </div>';
	if (substr($item, -1) === 'f') {
		$print['html'] .= "\r\n" . '  <div class="break"></div>';
	}
}

$print['html'] .= "\r\n\r\n" . '</body>' . "\r\n" . '</html>';

?>
<!DOCTYPE html>
<html>
<head>
	<title>Flaticon Webfont</title>
	<link rel="stylesheet" type="text/css" href="../css/flaticon.css">
	<meta charset="UTF-8">
	<style>
		table { width: 100%; }
		td { padding: 1em; }
		textarea { width: 100%; height: 80vh; }
	</style>
</head>
<body>
	<table>
		<tr>
			<td>HTML</td>
			<td>CSS</td>
		</tr>
		<tr>
			<td><textarea><?= $print['html']; ?></textarea></td>
			<td><textarea><?= $print['css']; ?></textarea></td>
		</tr>
	</table>
</body>
</html>