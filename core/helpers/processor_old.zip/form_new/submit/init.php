<?php

// мы получаем данные в нескольких видах:
// - данные, полученные из полей формы
// - настройки валидации этих данных
// - настройки очистки этих данных
// здесь стоит отметить, что очистка будет проводиться в любом случае,
// просто указанные параметры будут дополнять стандартную очистку
// 
// кроме этих данных, нам нужно получать дополнительную служебную информацию
// - имя модуля
// - токен для капчи
// - настройки модуля

// практичесвки для всего требуются настройки модуля!!!
// капча - вкл/выкл
// поля, тип, валидация
// кому отправлять в случае ок и отправлять ли уведомление
// и т.д. и т.п.

if ($process -> set -> status !== 'complete') :

// первым делом собираем данные из запроса

$module = (object) array(
	'path' => PATH_MODULES . $process -> set -> name . DS . 'data' . DS . $process -> set -> param,
	'base' => (object) array(
		'lang' => $currlang,
		'currdate' => date('d.m.Y H:i (P') . ' GMT)',
		'ip' => $_SERVER['REMOTE_ADDR'],
		'browser' => $_SERVER['HTTP_USER_AGENT'],
	),
	'settings' => [],
	'time' => 0
);

// вторым номером читаем настройки и объединяем их с предыдущими данными

$module -> settings = dbUse('modules:' . $process -> source['module'] . ($process -> source['module'] !== 'default' ? ':default' : null), 'select', ['allow' => 'parent:form', 'return' => 'name:data']);

if (objectIs($module -> settings)) {
	$keys = array_keys($module -> settings);
	if (in_array($process -> source['module'], $keys)) {
		$module -> settings = $module -> settings[$process -> source['module']];
	} else {
		$module -> settings = $module -> settings['default'];
	}
	unset($keys);
}

if (empty($module -> settings)) {
	$module -> settings = localFile(PATH_MODULES . 'form' . DS . 'data' . DS . $process -> source['module'] . '.ini');
	if (!empty($module -> settings)) {
		$module -> settings = iniPrepareJson($module -> settings, true);
	}
}

if (empty($module -> settings)) {
	exit;
}

echo '[<pre>' . print_r($module, 1) . '</pre>]<br>';
echo '[<pre>' . print_r($process, 1) . '</pre>]<br>';
exit;

// теперь начинаем эти данные песочить
// проверка на валидность

if (empty($module -> settings['redirect']) || empty($process -> set -> status)) :

require PATH_MODULES . 'form' . DS . 'process' . DS . 'functions.php';

foreach($module -> settings['form'] as $item) {
	
	$item['options'] = moduleFormOptionsGenerator($item['options']);
	
	if (is_array($process -> data[$item['name']])) {
		
		foreach($process -> data[$item['name']] as &$i) {
				
			$i = trim($i);
			
			if (
				!empty($item['verify']) &&
				$item['verify'] !== 'captcha' &&
				(!empty($item['required']) || !empty($i)) &&
				!datavalidation($i, $item['verify'])
			) {
				$i = htmlentities($i);
				$process -> errors[] = $item['name'];
			} elseif (
				!empty($item['verify']) &&
				$item['verify'] === 'captcha' &&
				!datavalidation($i, $item['verify'], $_SESSION['captcha_keystring'])
			) {
				$i = htmlentities($i);
				$process -> errors[] = $item['name'];
			} elseif (
				!empty($item['required']) &&
				empty($i)
			) {
				$i = htmlentities($i);
				$process -> errors[] = $item['name'];
			} elseif (!empty($item['filter'])) {
				
				// NEW
				
			} elseif (empty($item['nosend'])) {
				$i = htmlentities($i);
				if (!empty($item['message'])) {
					$module -> var['message'][$item['name']]['label'] = $item['message'];
				} else {
					$module -> var['message'][$item['name']]['label'] = $item['text'];
				}
				if (
					empty($process -> data[$item['name']]) &&
					!empty($item['novalue'])
				) {
					$module -> var['message'][$item['name']]['value'] .= htmlentities($item['novalue']) . '; ';
				} elseif (!empty($item['options'])) {
					$module -> var['message'][$item['name']]['value'] .= objectObject($item['options'], $i) . '; ';
				} else {
					$module -> var['message'][$item['name']]['value'] .= $i . '; ';
				}
			}
			
		}
		
	} else {
		
		$process -> data[$item['name']] = trim($process -> data[$item['name']]);
		
		if (!empty($item['filter'])) {
			$item['filter'] = htmlentities($item['filter']);
			$filter = datasplit($item['filter'], ' ');
			$filter = '(' . objectToString($filter, $splitter = ')|(') . ')';
			$item['filter'] = preg_match('/' . $filter . '/', $process -> data[$item['name']]);
		}
		
		if (
			!empty($item['verify']) &&
			$item['verify'] !== 'captcha' &&
			(!empty($item['required']) || !empty($process -> data[$item['name']])) &&
			!datavalidation($process -> data[$item['name']], $item['verify'])
		) {
			$process -> data[$item['name']] = htmlentities($process -> data[$item['name']]);
			$process -> errors[] = $item['name'];
		} elseif (
			!empty($item['verify']) &&
			$item['verify'] === 'captcha' &&
			!datavalidation($process -> data[$item['name']], $item['verify'], $_SESSION['captcha_keystring'])
		) {
			$process -> data[$item['name']] = htmlentities($process -> data[$item['name']]);
			$process -> errors[] = $item['name'];
		} elseif (
			!empty($item['required']) &&
			empty($process -> data[$item['name']])
		) {
			$process -> data[$item['name']] = htmlentities($process -> data[$item['name']]);
			$process -> errors[] = $item['name'];
		} elseif (!empty($item['filter'])) {
			$process -> data[$item['name']] = htmlentities($process -> data[$item['name']]);
			$process -> errors[] = $item['name'];
		} elseif (empty($item['nosend'])) {
			$process -> data[$item['name']] = htmlentities($process -> data[$item['name']]);
			if (!empty($item['message'])) {
				$module -> var['message'][$item['name']]['label'] = $item['message'];
			} else {
				$module -> var['message'][$item['name']]['label'] = $item['text'];
			}
			if (
				empty($process -> data[$item['name']]) &&
				!empty($item['novalue'])
			) {
				$module -> var['message'][$item['name']]['value'] = htmlentities($item['novalue']);
			} elseif (!empty($item['options'])) {
				$module -> var['message'][$item['name']]['value'] = objectObject((array)$item['options'], $process -> data[$item['name']]);
			} else {
				$module -> var['message'][$item['name']]['value'] = $process -> data[$item['name']];
			}
			
		}
		
	}
	
}

if (empty($process -> errors)) {
	$process -> set -> status = 'ready';
} else {
	$process -> set -> status = 'fail';
}

/*
print_r($process -> data);
echo '<br><br>';
print_r($module -> settings);
echo '<br><br>';
print_r($module -> var['message']);
echo '<br><br>';
//print_r($_GET);
exit;
*/

// если все ок, то запускаем функцию отправки оповещения админу (не пользователю!!!)

if (!empty($module -> settings['send']['template'])) {
	$module -> settings['send']['template'] = $process -> set -> param;
}

if (
	$process -> set -> status === 'ready' &&
	!empty($module -> settings['send']) &&
	message(
		$module -> settings['send'],
		$module -> settings['message']['subject'],
		/*
		(object) array(
			'label' => (object) $module -> label,
			'value' => (object) $module -> value
		),
		*/
		$module -> var['message'],
		$module -> settings['message']['text'],
		$module -> path . '_error',
		$process -> set -> status
	)
) {
	$process -> set -> status = 'complete';
}

// если в настройках включен лог, то записываем логи о пришедших сообщениях

if (!empty($module -> settings['log'])) {
	
	//$arr = dataloadcsv($module -> path . '_log');
	
	$arr = localOpenTable($module -> path . '_log.csv');
	
	if (empty($arr) || empty($arr -> data)) {
		$arr = (object) array(
			'data' => [
				[
					'date',
					'status',
					'ip',
					'browser',
					'message'
				]
			]
		);
	}
	
	$arr -> data[] = [
		datadatetime('','{dd}.{mm}.{yy} {hour}:{min}:{sec}'),
		//date('d.m.Y H:i:s (P') . ' GMT)',
		$process -> set -> status,
		$_SERVER['REMOTE_ADDR'],
		$_SERVER['HTTP_USER_AGENT'],
		$module -> settings['message']['text'] . ':' . $module -> settings['message']['subject'] . ':' . json_encode($module -> settings, JSON_UNESCAPED_UNICODE)
	];
	
	//datasavecsv($arr -> data, $module -> path . '_log');
	
	if ($handle = fopen($module -> path . '_log.csv', "w")) {
		if (is_array(reset($arr -> data))) {
			foreach ($arr -> data as $item) {
				fputcsv($handle, $item);
			}
			unset($item);
		} else {
			fputcsv($handle, $arr -> data);
		}
		fclose($handle);
	}
	unset($handle);
	
}

// если отправка не удалась, то мы подготавливаем редирект, а именно добавляем после статуса все введенные данные
// таким образом, при повторной загрузке, форма получит старые данные, а пользователю не придется вводить их заново
// можно было бы принять данные и когда все хорошо, но тогда их можно будет перехватить - это раз, и ссылка получится огромной - это два

if (!empty($module -> settings['time'])) {
	if (is_numeric($module -> settings['time'])) {
		$module -> time = time() + (int) $module -> settings['time'];
	} elseif ($module -> settings['time'] === 'hour') {
		$module -> time = time() + TIME_HOUR;
	} else {
		$module -> time = time();
	}
} else {
	$module -> time = time();
}

$module -> path = ($_SERVER['REDIRECT_URL']) ? $_SERVER['REDIRECT_URL'] : '/';

if (!empty($module -> settings['redirect'])) {
	$f = objectProcess('form:' . $process -> set -> name, null, $process -> set -> status);
	$module -> path .= $f['string'] . '&param=' . $process -> set -> param;
	unset($f);
}

if ($process -> set -> status === 'complete') {
	/*
	print_r($process);
	echo '<br><br>';
	print_r($_POST);
	exit;
	*/
	$f = objectProcess('form:' . $process -> set -> name, null, 'complete');
	$module -> path .= $f['string'] . '&param=' . $process -> set -> param;
	unset($f);
	header("Location: " . $module -> path);
	exit;
}

endif;
endif;

?>