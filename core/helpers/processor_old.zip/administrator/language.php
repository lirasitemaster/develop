<?php
defined('isPROCESS') or die;

$prefix = $query -> data -> prefix;

// обработка исходных данных

if (!empty($query -> data -> $prefix)) {
	if (!empty($query -> data -> json)) {
		$arr = iniMerge($query -> data -> $prefix, $query -> data -> json);
		$arr = json_decode($arr, true);
	} else {
		$arr = iniPrepareForm($query -> data -> $prefix);
	}
	$type = 'from json';
} else {
	exit;
}

// вывод

//$form = iniBuildForm($arr, $prefix);
//$form = iniBuildBlock($arr, $prefix, ['key2', 'key2-3', 'key2-3-2']);
//$form = iniBuildBlock($arr, $prefix, ['key2', 'key2-3']);

$json_dec = iniPrepareArray($arr);

echo '<pre><p>json output</p><p>';
echo $json_dec;
echo '</p></pre>';

//print_r($prefix);
print_r($query -> data -> $prefix);
exit;

?>