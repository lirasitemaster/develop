<?php
echo 'GET: ';
print_r($_GET);
echo '<br><br>';
echo 'POST: ';
print_r($_POST);
echo '<br><br>';
echo 'REQUEST: ';
print_r($_REQUEST);
?>