<?php
defined('isPROCESS') or die;

deleteProject('delete', $userID, $_POST['project']);

exit;

?>