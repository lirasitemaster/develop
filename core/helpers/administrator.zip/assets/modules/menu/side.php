<?php
	
	$data = array_shift($data);
	$labels = $module -> settings['labels'];
	$icons = $module -> settings['icons'];
	//global $structure;
	//echo '<pre>' . print_r($structure, 1) . '</pre>';
	//echo '<pre>' . print_r($data, 1) . '</pre>';
	
?>

<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="menu<?= $module -> param; ?>">

	<!-- Sidebar - Brand -->
	<a class="sidebar-brand d-flex align-items-center justify-content-center" href="/administrator/">
		<div class="sidebar-brand-icon rotate-n-15">
			<i class="fas fa-laugh-wink"></i>
		</div>
		<div class="sidebar-brand-text mx-3">SB Admin <sup>2</sup></div>
	</a>

	<!-- Divider -->
	<hr class="sidebar-divider my-0">

	<?php
		foreach ($data as $key => $item) :
			$key = dataParse($key);
			// 0 - id
			// 1 - name
			// 2 - type
			// 3 - link
			
			if ($key[2] === 'group' && objectIs($item)) :
	?>
				
				<!-- Divider -->
				<hr class="sidebar-divider">
				<!-- Heading -->
				<div class="sidebar-heading">
					<?= $labels[$key[1]]; ?>
				</div>
				
				<?php
					foreach ($item as $k => $i) :
						$k = dataParse($k);
				?>
						<li class="nav-item">
							
							<?php if ($k[2] === 'group' && objectIs($i)) : ?>
								<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse<?= $k[1]; ?>" aria-expanded="true" aria-controls="collapse<?= $k[1]; ?>">
							<?php else : ?>
								<a class="nav-link" href="/<?= str_replace('.', '/', $k[3]); ?>">
							<?php endif; ?>
								<?php if (!empty($icons[$k[1]])) : ?>
									<i class="<?= $icons[$k[1]]; ?>"></i>
								<?php endif; ?>
									<span><?= $labels[$k[1]]; ?></span>
								</a>
							
							<?php if ($k[2] === 'group' && objectIs($i)) : ?>
								
								<div id="collapse<?= $k[1]; ?>" class="collapse" aria-labelledby="heading<?= $k[1]; ?>" data-parent="#menu<?= $module -> param; ?>">
									<div class="bg-white py-2 collapse-inner rounded">
									
										<?php
											foreach ($i as $ki => $ii) :
												$ki = dataParse($ki);
										?>
												
												<h6 class="collapse-header"><?= $labels[$ki[1]]; ?>:</h6>
												
												<?php
													if ($ki[2] === 'group' && objectIs($ii)) :
														foreach ($ii as $kii => $iii) :
															$kii = dataParse($kii);
												?>
															<a class="collapse-item" href="/<?= str_replace('.', '/', $kii[3]); ?>"><?= $labels[$kii[1]]; ?></a>
												<?php
														endforeach;
														unset($kii, $iii);
													endif;
												?>
												
												<div class="collapse-divider"></div>
												
										<?php
											endforeach;
											unset($ki, $ii);
										?>
										
									</div>
								</div>
								
						<?php endif; ?>
						
					</li>
	<?php
				endforeach;
				unset($k, $i);
				
			else :
	?>
				<li class="nav-item">
					<a class="nav-link" href="/<?= str_replace('.', '/', $key[3]); ?>">
	<?php
					if (!empty($icons[$key[1]])) :
	?>
						<i class="<?= $icons[$key[1]]; ?>"></i>
	<?php
					endif;
	?>
						<span><?= $labels[$key[1]]; ?></span>
					</a>
				</li>
	<?php
			endif;
			
		endforeach;
		unset($key, $item);
	?>
	
	<!-- Divider -->
	<hr class="sidebar-divider d-none d-md-block">

	<!-- Sidebar Toggler (Sidebar) -->
	<div class="text-center d-none d-md-inline">
		<button class="rounded-circle border-0" id="sidebarToggle"></button>
	</div>

</ul>
<!-- End of Sidebar -->
