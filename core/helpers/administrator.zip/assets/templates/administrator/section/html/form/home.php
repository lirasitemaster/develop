<?php defined('isCMS') or die;
page('opening', 'template');
?>

<body class="bg-gradient-primary">

  <div class="container">
    <!-- Outer Row -->
    <div class="row justify-content-center">
      <div class="col-xl-10 col-lg-12 col-md-9">
        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0 row">
            <!-- Nested Row within Card Body -->
			<div class="col"></div>
			<?php
				global $uri;
				$key = !empty($uri -> query -> array) && in_array(key($uri -> query -> array), ['forgot-password', 'login', 'register']) ? key($uri -> query -> array) : 'login';
				page('form:' . $key, 'html');
				unset($key);
				page('form:buttons', 'html');
			?>
			</div>
			</div>
			<div class="col"></div>
			
          </div>
        </div>
      </div>
    </div>
  </div>

<?php page('ending', 'template'); ?>