<?php $o = objectProcess('user:logout'); ?>

<form class="user" action="<?= $o['action']; ?>">
	
	<?php
		foreach ($o['fields'] as $i) {
			echo $i;
		}
		unset($i);
	?>
	
	<button type="submit" class="btn btn-primary btn-user btn-block" name="data" value="1">
		Exit [<?= lang('section:data-exit'); ?>]
	</button>
</form>

<?php unset($o); ?>