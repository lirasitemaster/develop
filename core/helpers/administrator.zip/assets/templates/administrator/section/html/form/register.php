<div class="col-lg-7">
  <div class="p-5">
    <div class="text-center">
      <h1 class="h4 text-gray-900 mb-4"><?= lang('section:header-register'); ?></h1>
    </div>
	
<?php

global $userstable;
global $user;

$o = objectProcess('user:register');
$fields = dbUse($userstable, 'filter', ['filter' => 'required system:password:authorise', 'or' => true]);

?>
	
    <form class="user" action="<?= $o['action']; ?>" method="post">
	
<?php

foreach ($o['fields'] as $i) {
	echo $i;
}
unset($i);

static $n;
$n = null;

foreach ($fields as $item) {
	
	$data = $item['data'];
	
	if (!empty($data['system']) && $data['system'] === 'password') {
		echo '
			<div class="form-group row">
				<div class="col-sm-6 mb-3 mb-sm-0">
					<input type="password" name="data[' . $item['name'] . ']" class="form-control form-control-user" placeholder="' . lang('section:data-password') . '" required />
				</div>
				<div class="col-sm-6">
					<input type="password" name="data[' . $item['name'] . '-repeat]" class="form-control form-control-user" placeholder="' . lang('section:data-password-repeat') . '" required />
				</div>
			</div>
		';
	} else {
		echo '
			<div class="form-group">
				<input type="' . (!empty($data['type']) ? $data['type'] : 'text') . '" name="data[' . $item['name'] . ']" class="form-control form-control-user" placeholder="' . lang('section:data-' . $item['name']) . '"' . (!empty($data['required']) ? ' required' : null) . ' />' . 
				(!empty($data['required']) ? ' <span class="small">* ' . lang('section:data-field-required') . '</span>' : null) . 
				(!empty($data['system']) && $data['system'] === 'authorise' && $n > 0 ? ' <span class="small">* ' . lang('section:data-field-authorise') . '</span>' : null) . '
			</div>
		';
	}
	
	if (!empty($data['system']) && $data['system'] === 'authorise') {
		$n++;
	}
	
}
unset($item, $data, $n);

?>
		<button type="submit" class="btn btn-primary btn-user btn-block">
			<?= lang('section:data-register'); ?>
		</button>
		
		<?/*
		  <hr>
		  <a href="login.html" class="btn btn-primary btn-user btn-block">
			<?= lang('section:data-register'); ?>
		  </a>
		  <a href="index.html" class="btn btn-google btn-user btn-block">
			<i class="fab fa-google fa-fw"></i> Register with Google
		  </a>
		  <a href="index.html" class="btn btn-facebook btn-user btn-block">
			<i class="fab fa-facebook-f fa-fw"></i> Register with Facebook
		  </a>
		*/?>
		
    </form>

<?php
unset($o);
//echo 'fields:<br><pre>' . print_r($fields, 1) . '</pre><hr>';
//echo 'userstable:<br><pre>' . print_r($userstable, 1) . '</pre><hr>';
//echo 'user:<br><pre>' . print_r($user, 1) . '</pre><hr>';
?>