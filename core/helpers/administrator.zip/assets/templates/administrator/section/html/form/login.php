<div class="col-lg-6">
	<div class="p-5">
		
		<div class="text-center">
			<h1 class="h4 text-gray-900 mb-4"><?= lang('section:header-login'); ?></h1>
		</div>
		
		<?php $o = objectProcess('user:authorise'); ?>
		
		<form class="user" action="<?= $o['action']; ?>">
			
			<?php
				foreach ($o['fields'] as $i) {
					echo $i;
				}
				unset($i);
			?>
			
			<div class="form-group">
				<input name="data[name]" type="text" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="<?= lang('section:data-login-enter'); ?>">
			</div>
			<div class="form-group">
				<input name="data[password]" type="password" class="form-control form-control-user" id="exampleInputPassword" placeholder="<?= lang('section:data-password'); ?>">
			</div>
			<div class="form-group">
				<div class="custom-control custom-checkbox small">
					<input type="checkbox" class="custom-control-input" id="customCheck">
					<label class="custom-control-label" for="customCheck"><?= lang('section:data-remember'); ?></label>
				</div>
			</div>
			<button type="submit" class="btn btn-primary btn-user btn-block">
				<?= lang('section:data-authorise'); ?>
			</button>
			<?/*
			<hr>
			<a href="index.html" class="btn btn-google btn-user btn-block">
				<i class="fab fa-google fa-fw"></i> Login with Google
			</a>
			<a href="index.html" class="btn btn-facebook btn-user btn-block">
				<i class="fab fa-facebook-f fa-fw"></i> Login with Facebook
			</a>
			*/?>
		</form>
		
		<?php unset($o); ?>