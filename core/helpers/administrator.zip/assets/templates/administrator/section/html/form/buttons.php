<hr>
<?php
	global $uri;
	$key = !empty($uri -> query -> array) ? key($uri -> query -> array) : 'login';
	foreach (['login', 'forgot-password', 'register'] as $item) :
		if ($item !== $key) :
?>
<div class="text-center">
  <a class="small" href="<?= $uri -> site . $uri -> path -> string . '?' . $item; ?>"><?= lang('section:' . $item); ?></a>
</div>
<?php
		endif;
	endforeach;
	unset($item, $key);
?>