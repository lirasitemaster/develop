<?php defined('isENGINE') or die;

global $user;
if (empty($user -> uid)) {
	page('form:home', 'html');
} else {
	
	page('common:exit', 'html');
	echo 'is joined';
	
}

?>