<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <?php //page('panels:side', 'html'); ?>
	<?php module(['menu', 'side']); ?>
	
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

		<?php page('panels:top', 'html'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
