<?php if (thispage('is') === 'charts') : ?>

<!-- Page level plugins -->
<script src="/vendor/chartjs/chart.js/dist/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="/<?= URL_ASSETS; ?>js/administrator/demo/chart-area-demo.js"></script>
<script src="/<?= URL_ASSETS; ?>js/administrator/demo/chart-pie-demo.js"></script>
<script src="/<?= URL_ASSETS; ?>js/administrator/demo/chart-bar-demo.js"></script>

<?php elseif (thispage('is') === 'home' && !objectGet('template', 'section')) : ?>

<!-- Page level plugins -->
<script src="/vendor/chartjs/chart.js/dist/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="/<?= URL_ASSETS; ?>js/administrator/demo/chart-area-demo.js"></script>
<script src="/<?= URL_ASSETS; ?>js/administrator/demo/chart-pie-demo.js"></script>

<?php endif; ?>
