<?php defined('isCMS') or die;

page('opening', 'item');
page('first', 'html');
page('routing', 'item');
page('last', 'html');
page('ending', 'item');

?>