<?php

$time = [
	'day' => !empty($_GET['day']) ? $_GET['day'] : null,
	'from' => !empty($_GET['from']) ? $_GET['from'] : null,
	'to' => !empty($_GET['to']) ? $_GET['to'] : null,
	'absfrom' => null,
	'absto' => null,
	'format' => '{yy}-{mm}-{dd}',
	'point' => null
];

if (
	!empty($time['from']) &&
	!empty($time['to']) &&
	$time['from'] > $time['to']
) {
	$n = $time['from'];
	$time['from'] = $time['to'];
	$time['to'] = $n;
	unset($n);
}

?>

<form action="" method="get" class="report-form">
за один день <input name="day" type="date" value="<?= $time['day']; ?>" />
<br>
за период <input name="from" type="date" value="<?= $time['from']; ?>" /> - <input name="to" type="date" value="<?= $time['to']; ?>" />
<br>
<input type="submit" />
</form>

<?php

if (!empty($time['day'])) {
	$time['from'] = $time['day'];
	$time['to'] = $time['day'];
}

$time['absfrom'] = !empty($time['from']) ? datadatetime($time['from'], $time['format'], true) : null;
$time['absto'] = !empty($time['to']) ? datadatetime($time['to'], $time['format'], true) + TIME_DAY : null;

$path = PATH_ASSETS . 'send' . DS . 'log' . DS;
$files = localList($path, ['return' => 'files']);
$table = [];
$count = null;

if (objectIs($files)) {
	
	$count = count($files);
	
	foreach ($files as $key => $item) {
		
		$target = iniPrepareJson(localFile($path . $item), true);
		
		$date = empty($time['point']) ? filemtime($path . $item) : $target['data'][$time['point']];
		//echo '[' . $date . ']';
		
		if (
			!empty($time['absfrom']) && $date < $time['absfrom'] ||
			!empty($time['absto']) && $date > $time['absto']
		) {
			continue;
		}
		
		unset($date);
		
		if (
			objectIs($target) &&
			objectIs($target['data']) &&
			$target['status'] === 'ok' &&
			$target['sets']['type'] === 'mail' &&
			$target['subject'] === 'Новый заказ с сайта'
		) {
			
			foreach ($target['data'] as $k => $i) {
				$table[$k][$key] = $i;
			}
			
			unset($key, $item);
			
			//echo '[' . htmlentities(print_r($i, 1)) . '<br><br>';
		}
		
		//echo '[' . print_r($i, 1) . '<br>';
	}
	unset($key, $item);
	
} else {
	
	echo '<br>Список пуст';
	
}

//print_r($table);

$sostav = null;

if (objectIs($table)) {
	
	$head = array_keys($table);
	
	if (objectIs($head)) {
		
		echo '<table class="report"><thead><tr>';
		echo '<th>№</th>';
		
		foreach ($head as $key => $item) {
			echo '<th>' . clear($item) . '</th>';
		}
		unset($key, $item);
		
		echo '</tr></thead><tbody>';
		
		while ($count > 0) {
		//for (null; $count > 0; $count--) {
			
			$c = count($head);
			$i = null;
			
			foreach ($head as $item) {
				$i .= '<td>' . clear($table[$item][$count - 1]) . '</td>';
				if (!empty($table[$item][$count - 1])) {
					$c--;
				}
				
				if (mb_strtolower($item) === 'состав заказа') {
					$sostav .= clear($table[$item][$count - 1]);
				}
				
			}
			unset($item);
			
			if ($c < count($head)) {
				echo '<tr><td>' . $count . '</td>' . $i . '</tr>';
			}
			
			$count--;
			unset($i, $c);
		}
		
		echo '</tbody></table>';
		
	}
	
} elseif (objectIs($files)) {
	echo '<br>Нет записей, соответствующих заданному условию';
}

if (!empty($sostav)) {
	
	$sostav = datasplit($sostav, '<br>');
	$sarr = [];
	
	foreach ($sostav as $key => $item) {
		
		//$item = preg_replace('/^\s*\d+\s\:\s/ui', null, $item);
		//preg_match('/^\s*\d+\s\:\s(.*)?\,\s([\d\,\.]+)?\s  \s+артикул\:\s(\d+)\]/ui', $item, $smatch);
		preg_match('/^\s*\d+\s\:\s(.*)?\,\s([\d\,\.]+)?\s.*?\-\s([\d\,\.]+).*?(артикул)\:\s(\d+)/ui', $item, $smatch);
		
		$sname = $smatch[5] . ':' . $smatch[1];
		
		$smatch[2] = !empty($smatch[2]) ? (float) str_replace(',', '.', $smatch[2]) : 0;
		$smatch[3] = !empty($smatch[3]) ? (float) str_replace(',', '.', $smatch[3]) : 0;
		
		if (!array_key_exists($sname, $sarr)) {
			
			$sarr[$sname] = [
				'count' => $smatch[2],
				'price' => $smatch[3]
			];
			
		} else {
			
			$sarr[$sname]['count'] += $smatch[2];
			$sarr[$sname]['price'] += $smatch[3];
			
		}
		
	}
	unset($key, $item);
	
}

if (!empty($sarr)) {
	ksort($sarr);
	
	echo '<br><br><table class="report"><thead><tr><th>артикул</th><th>название</th><th>кол-во</th><th>сумма</th></tr></thead><tbody>';
	foreach ($sarr as $key => $item) {
		$key = dataSplit($key, ':');
		echo '<tr><td>' . $key[0] . '</td><td>' . $key[1] . '</td><td>' . $item['count'] . '</td><td>' . $item['price'] . '</td></tr>';
	}
	unset($key, $item);
	echo '</tbody></table>';
	
}

?>

