<?php
define('isENGINE', '0.10.0');
define('CMS_MINIMUM_PHP', '5.6.0');
define('DS', DIRECTORY_SEPARATOR);
define('DP', '..' . DIRECTORY_SEPARATOR);
define('PATH_SITE', realpath(__DIR__) . DS);
define('PATH_BASE', realpath(__DIR__ . DS . '..') . DS);

// Подключаем файл конфигурации
require_once PATH_SITE . 'configuration.php';

// Выполняем инициализацию
require_once PATH_CORE . 'init.php';

?>