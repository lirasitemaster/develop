<?php defined('isCMS') or die;

file_exists(__DIR__ . DS . 'configuration.ini') or die('SYSTEM ERROR: System could not find [configuration.ini] file in the main site folder. All system processes have been stopped!');

$configuration = json_decode(file_get_contents(__DIR__ . DS . 'configuration.ini'), true) or die('SYSTEM ERROR: System file [configuration.ini] contains errors or is incorrectly formatted. All system processes have been stopped!');

if (
	$_SERVER['REMOTE_ADDR'] === '127.0.0.1' &&
	file_exists(__DIR__ . DS . 'configuration.local.ini')
) {
	$localconf = json_decode(file_get_contents(__DIR__ . DS . 'configuration.local.ini'), true);
	$configuration = array_replace_recursive($configuration, $localconf);
	unset($localconf);
}

foreach ($configuration as $key => $item) {
	if ($key !== 'name') {
		foreach ($item as $k => $i) {
			define(strtoupper($key . '_' . $k), $i);
		}
	} elseif (!empty($item) && is_array($item)) {
		foreach ($item as $k => $i) {
			
			$k = strtoupper($k);
			
			$dir = substr(str_replace([':', '\\', '/', '\\\\', '//', '\\/', '/\\'], DS, DS . $i[1] . DS), 1, -1) . DS . $i[0];
			if (strpos($dir, '..' . DS) !== false) {
				$url = '';
				$dir = PATH_BASE . substr($dir, 3);
			} elseif (strpos($dir, DS) === 0) {
				$url = str_replace(DS, '/', substr($dir, 1)) . '/';
				$dir = PATH_SITE . substr($dir, 1);
			} else {
				$url = str_replace(DS, '/', $dir) . '/';
				$dir = PATH_SITE . $dir;
			}
			
			define('NAME_' . $k, $i[0]);
			define('PATH_' . $k, $dir . DS);
			define('URL_' . $k, $url);
			
			unset($dir, $url);
			
		}
	}
}

/*
"name" : {
	"database" : ["base", ""],
	"assets" : ["assets", ""],
	"cache" : ["cache", ""],
	"core" : ["core", "vendor:iscms"],
	"libraries" : ["vendor", ""],
	"local" : ["local", ""],
	"log" : ["log", ""],
	"modules" : ["iscms", "vendor"],
	"templates" : ["templates", ""]
}
*/

if (empty($configuration['name']) || !is_array($configuration['name'])) {
	
	define('NAME_DATABASE', 'base');
	define('PATH_DATABASE', PATH_SITE . 'base' . DS);
	define('URL_DATABASE', '/');
	
	define('NAME_ASSETS', 'assets');
	define('PATH_ASSETS', PATH_SITE . 'assets' . DS);
	define('URL_ASSETS', 'assets/');
	
	define('NAME_CACHE', 'cache');
	define('PATH_CACHE', PATH_SITE . 'cache' . DS);
	define('URL_CACHE', 'cache/');
	
	define('NAME_CORE', 'core');
	define('PATH_CORE', PATH_SITE . 'vendor' . DS . 'iscms' . DS . 'core' . DS);
	define('URL_CORE', 'vendor/iscms/core/');
	
	define('NAME_LIBRARIES', 'vendor');
	define('PATH_LIBRARIES', PATH_SITE . 'vendor' . DS);
	define('URL_LIBRARIES', 'vendor/');
	
	define('NAME_LOCAL', 'local');
	define('PATH_LOCAL', PATH_SITE . 'local' . DS);
	define('URL_LOCAL', 'local/');
	
	define('NAME_LOG', 'log');
	define('PATH_LOG', PATH_SITE . 'log' . DS);
	define('URL_LOG', 'log/');
	
	define('NAME_MODULES', 'vendor');
	define('PATH_MODULES', PATH_SITE . 'vendor' . DS);
	define('URL_MODULES', 'vendor/');
	
	//define('NAME_MODULES', 'iscms');
	//define('PATH_MODULES', PATH_SITE . 'vendor' . DS . 'iscms' . DS);
	//define('URL_MODULES', 'vendor/iscms/');
	
	define('NAME_TEMPLATES', 'templates');
	//define('PATH_TEMPLATES', PATH_SITE . 'templates' . DS);
	//define('URL_TEMPLATES', 'templates/');
	define('PATH_TEMPLATES', PATH_SITE . 'assets' . DS . 'templates' . DS);
	define('URL_TEMPLATES', 'assets/templates/');
	
}

unset($configuration, $key, $item, $k, $i);

// создание констант времени

define('TIME_MINUTE', 60);
define('TIME_HOUR', 3600);
define('TIME_DAY', 86400);
define('TIME_WEEK', 604800);
define('TIME_MONTH', 2628000);
define('TIME_YEAR', 31556926);

// создание нескольких системных констант
define('USER_AGENT', $_SERVER['HTTP_USER_AGENT']);
define('USER_SENDER', 'X-Mailer: PHP/' . phpversion());

// задаем конфигурацию php

// принудительно устанавливаем имя идентификатора сессии
// т.к. например в nginx он отказывается его принимать в конфиге

ini_set('session.name', 'SID');

// вывод ошибок рекомендуется включать только на время разработки

if (defined('DEFAULT_MODE') && DEFAULT_MODE === 'develop') {
	ini_set('display_errors', 'on');
	ini_set('display_startup_errors', true);
	if (defined('LOG_MODE') && LOG_MODE === 'panic') {
		ini_set('error_reporting', E_ALL);
	} else {
		ini_set('error_reporting', E_ALL & ~E_NOTICE);
	}
} else {
	ini_set('display_errors', 'off');
	ini_set('display_startup_errors', false);
	ini_set('error_reporting', 0);
}

// дополнительные установки локали

ini_set('default_charset', 'UTF-8');

if (version_compare(PHP_VERSION, '5.6.0', '<') && function_exists('mb_internal_encoding')) {
	mb_internal_encoding('UTF-8');
}
if (function_exists('mb_regex_encoding')) {
	mb_regex_encoding('UTF-8');
}

if (defined('DEFAULT_TIMEZONE') && !empty(DEFAULT_TIMEZONE)) {
	date_default_timezone_set(DEFAULT_TIMEZONE);
}

?>