<?php defined('isCMS') or die;

init('init', 'fast');

global $uri;
global $lang;

//print_r($uri);
//print_r($lang);
//echo isERROR;

// создаем базовый объект
$error = (object) [
	'code' => '',
	'lang' => htmlspecialchars($lang -> lang),
	'description' => '',
	'name' => '',
	'message' => '',
	'support' => '',
	'path' => __DIR__ . DS,
	'link' => '/' . URL_TEMPLATES . DEFAULT_ERRORS . '/',
	'previous' => $uri -> scheme . '://' . $uri -> host . $uri -> path -> base . cookie('previous-url', true),
	'data' => (object) array(),
	'options' => (object) array()	
];

// устанавливаем код ошибки

if (!empty($_GET['error'])) {
	$error -> code = htmlspecialchars($_GET['error']);
} elseif (defined('isERROR') && isERROR) {
	$error -> code = htmlspecialchars(isERROR);
}

// читаем настройки и тексты для кодов ошибок
$error -> options = (object) dataprepare($error -> path . 'settings.ini');
$error -> data = (object) dataprepare($error -> path . 'lang.ini');

// проверяем адрес почты и если пустой, то устанавливаем дефолтный
if (empty($error -> options -> mail)) {
	if (defined('USERS_EMAIL') && USERS_EMAIL) {
		$error -> options -> mail = USERS_EMAIL;
	} else {
		$error -> options -> mail = 'support@' . $_SERVER['SERVER_NAME'];
	}
}

// проверяем язык и устанавливаем первый из набора в качестве дефолтного
if (!in_array((string) $error -> lang, $error -> options -> langs)) {
	$error -> lang = $error -> options -> langs[0];
}

// проверяем и устанавливаем статус
if (in_array((string) $error -> code, $error -> options -> statuses)) {
	$error -> name = $error -> options -> status[$error -> lang];
} elseif (in_array((string) $error -> code, $error -> options -> errors)) {
	$error -> name = $error -> options -> error[$error -> lang];
}

// задаем базовые значения объектов для использования в шаблоне

$error -> description = (array)$error -> data;
$error -> description = $error -> description[(string) $error -> code][$error -> lang]['description'];
$error -> description = trim($error -> description);
$error -> message = (array)$error -> data;
$error -> message = $error -> message[(string) $error -> code][$error -> lang]['message'];
$error -> message = trim($error -> message);

$error -> support = $error -> options -> support[$error -> lang] . '<a href="mailto: ' . $error -> options -> mail . '?subject=' . $error -> name . '_' . $error -> code . '">' . $error -> options -> mail . '</a>';

// производим замену содержимого текста
if ($error -> message) {
	$error -> message = str_replace(
		[
			'{timer}',
			'{previous}',
			'{restore}',
			'{host}',
			'{block}',
			'{support}',
			'{phpversion}'
		],
		[
			'<span id="timer">' . $error -> options -> timer . '</span>',
			'<a href="' . $error -> previous . '">' . $error -> previous . '</a>',
			'<a href="/?query=restore">' . $error -> options -> restore[$error -> lang] . '</a>',
			'<a href="/">http://' . $_SERVER['SERVER_NAME'] . '</a>',
			$error -> options -> block[$error -> lang],
			'<a href="mailto: ' . $error -> options -> mail . '?subject=' . $error -> name . ' ' . $error -> code . ' (' . $_SERVER['SERVER_NAME'] . ')">' . $error -> options -> mail . '</a>',
			CMS_MINIMUM_PHP
		],
		$error -> message
	);
}

unset($error -> data);

//echo '<pre>';
//print_r($error);
//echo '</pre>';
//exit;

// загружаем шаблон
require_once $error -> path . 'html' . DS . 'default.php';

// функция dataprepare, объединяющая dataloadjson и clear
// с урезанными возможности только для данного конкретного случая
// внимание! теперь можно загружать функцию dataloadjson отдельно через init, а clear является системной и грузится в самом начале

function dataprepare($data){
	
	if (!file_exists($data)) {
		return false;
	}
	
	$data = file_get_contents($data);
	
	// выполняем предварительное очищение - от переносов и табуляций
	$data = preg_replace('/\r\n/', '', $data);
	$data = preg_replace('/\n/', '', $data);
	$data = preg_replace('/\t/', ' ', $data);
	
	// выполняем предварительное очищение - от скриптов, программного кода
	$data = preg_replace('/<\?.+?\?>/','', $data);
	$data = preg_replace('/<script.+?\/script>/','', $data);
	
	// продолжаем предварительное очищение - от всех тегов, кроме разрешенных
	// задаем разрешенные теги
	$tags = ['br', 'p', 'span', 'b', 'i', 's', 'u', 'strong', 'em', 'del', 'small', 'sub', 'sup', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li', 'pre', 'hr'];
	// подготавливаем список
	$striptags = '';
	foreach ($tags as $tag) {
		$striptags .= '<' . $tag . '>';
	}
	// очищаем
	$data = strip_tags($data, $striptags);
	// завершаем
	unset($tags, $tag, $striptags);
	
	// продолжаем предварительное очищение - чистим текст от пробелов и отступов в начале и в конце
	$data = trim($data);
	$data = preg_replace('/^(&nbsp;)+/', '', $data);
	$data = preg_replace('/(&nbsp;)+$/', '', $data);
	
	// продолжаем предварительное очищение - чистим текст от двойных пробелов
	$data = preg_replace('/(\s|&nbsp;){2,}/', '$1', $data);
	
	$data = json_decode($data, true);
	
	return $data;
	
}

?>