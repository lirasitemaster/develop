<?php defined('isENGINE') or die; ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<title><?= $error -> name . ' ' . $error -> code; ?></title> 
	<link rel="stylesheet" rev="stylesheet" type="text/css" href="<?= $error -> link; ?>css/style.css" />
</head>
<body>

<div>
	
	<p align="center">
		<strong>
		<?= $error -> name; ?> <span class="code" data-text="<?= $error -> code; ?>"><?= $error -> code; ?><span class="colon">:</span></span> <?= $error -> description; ?>
		</strong>
	</p>
	
	<?= $error -> message; ?>
	
</div>

<script type="text/javascript" src="<?= $error -> link; ?>js/script.js"></script>

</body>
</html>