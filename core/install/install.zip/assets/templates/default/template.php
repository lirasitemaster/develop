<?php defined('isENGINE') or die; ?>
<?php page('opening', 'item'); ?>

	<div id="wrapper">
	
		<div id="head">
		</div>
		
		<div id="menu">
			<?php module(['menu']); ?>
		</div>
		
		<div id="content">
			<?php page('routing', 'item'); ?>
		</div>
		
<?php page('ending', 'item'); ?>