<?php defined('isCMS') or die;

//echo 'ORDER';

//echo '<br>' . print_r($process, 1) . '<br>';
//echo '<br>' . print_r($module, 1) . '<br>';

// проверка ошибок и присвоение статуса (будет присвоен в зависимости от наличия ошибок)
// if (empty($process -> errors))
// для продолжения
// $process -> set -> status = 'ready';
// для отмены
// $process -> set -> status = 'fail';

// шаблон
// $module -> settings['send']['template'] = $process -> source['module'];

// функция отправки оповещения админу (не пользователю!!!)
// send(
//	$module -> settings['send'],
//	$module -> settings['message']['text'],
//	$module -> settings['message']['subject'],
//	$module -> var['message']
// )

// описание функции
// function send($arr, $message, $subject = null, $data = [], $clear = null) {
//	*  функция принимает данные и отправляет сообщения
//	*  на данный момент реализована отправка email, vk, whatsapp, sms
//	*  обработки и проверки данных пока нет
//	*  
//	*  на входе нужно указать:
//	*    arr - массив данных (напр. "type" : "mail", "param" : "", "id" : "mail@mail.com", "key" : "")
//	*    subject - тема сообщения
//	*    data - массив данных [key => item], где key - название, item - значение
//	*    message - текстовое сообщение
//	*    clear - параметры очистки
//	*    template - разрешен ли шаблон и указываем здесь имя шаблона (теперь в составе $arr -> template)

// теперь логи записываются автоматически в функции send

// успешный статус при наличии параметров отправки, хорошего статуса статуса и после успешной отправки сообщения
// $process -> set -> status = 'complete';

if (defined('CORE_SHOP') && CORE_SHOP) {
	init('class', 'shop');
}

global $template;
$template = objectMerge($template, (object) ['settings' => (object) ['options' => ['dictionary']]]);

/*
if (empty($template)) { $template = (object) []; }
if (empty($template -> settings)) { $template -> settings = (object) []; }
if (empty($template -> settings -> options)) { $template -> settings -> options = []; }
if (!in_array('dictionary', $template -> settings -> options)) { $template -> settings -> options[] = 'dictionary'; }
*/

init('functions', 'templates');
init('templates' . DS . 'init', 'languages');

$target = iniPrepareJson(base64_decode($process -> source['this']), true);

$shop = new Shop($target[0]);
$shop -> read($target[1]);

//echo '<br>shop<br><pre>' . print_r($shop, 1) . '</pre><br>';

$sku = $shop -> settings['sku'];
$price = $shop -> settings['price'];
$i = 0;

foreach ($shop -> order as $item) {
	
	$data = $item['data'];
	
	$i++;
	$v = $shop -> cart[$data[$sku]];
	$t = '<br>[' . $i . '] : ' . $data['title'] . ', ' . $v . ' ' . $data['units'] . ' - ' . ($data[$price] * $v) . ' руб (' . $v . ' x ' . $data[$price] . ' руб) [артикул: ' . $data[$sku] . ']';
	
	$module -> var['message']['Состав заказа'] .= $t;
	
	unset($data, $t, $v);
	
}
unset($item);

$module -> var['message']['Итого'] = $shop -> prices['total'] . ' руб';
//$module -> var['message']['Дата'] = dataDateTime(null, '{dd}.{mm}.{yy} {hour}:{min}');
$module -> var['message']['Дата'] = dataDateTime(null, '{WW}, {dd} {MM:r} {yy} {hour}:{min}');

//echo '<br><pre>' . print_r($module -> var['message'], 1) . '</pre><br>';

$module -> var['cookie'] = ['cart' => null];

?>