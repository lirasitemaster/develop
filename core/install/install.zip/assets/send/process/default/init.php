<?php defined('isENGINE') or die;

echo '<br>DEFAULT<br>';

echo '<br>' . print_r($process, 1) . '<br>';
echo '<br>' . print_r($module, 1) . '<br>';

// проверка ошибок и присвоение статуса (будет присвоен в зависимости от наличия ошибок)
// if (empty($process -> errors))
// для продолжения
// $process -> set -> status = 'ready';
// для отмены
// $process -> set -> status = 'fail';

// шаблон
// $module -> settings['send']['template'] = $process -> source['module'];

// функция отправки оповещения админу (не пользователю!!!)
// send(
//	$module -> settings['send'],
//	$module -> settings['message']['text'],
//	$module -> settings['message']['subject'],
//	$module -> var['message']
// )

// описание функции
// function send($arr, $message, $subject = null, $data = [], $clear = null) {
//	*  функция принимает данные и отправляет сообщения
//	*  на данный момент реализована отправка email, vk, whatsapp, sms
//	*  обработки и проверки данных пока нет
//	*  
//	*  на входе нужно указать:
//	*    arr - массив данных (напр. "type" : "mail", "param" : "", "id" : "mail@mail.com", "key" : "")
//	*    subject - тема сообщения
//	*    data - массив данных [key => item], где key - название, item - значение
//	*    message - текстовое сообщение
//	*    clear - параметры очистки
//	*    template - разрешен ли шаблон и указываем здесь имя шаблона (теперь в составе $arr -> template)

// теперь логи записываются автоматически в функции send

// успешный статус при наличии параметров отправки, хорошего статуса статуса и после успешной отправки сообщения
// $process -> set -> status = 'complete';

if (defined('CORE_SHOP') && CORE_SHOP) {
	init('class', 'shop');
}

$target = iniPrepareJson(base64_decode($process -> source['this']), true);

$shop = new Shop($target[0]);
$shop -> read($target[1]);

echo '<br>shop<br><pre>' . print_r($shop, 1) . '</pre><br>';

exit;

?>