$(function(){
/** start script **/



/** end script **/
});