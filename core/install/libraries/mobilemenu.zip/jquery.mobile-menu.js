/**
* Off-canvas mobile menu Script for isCMS
* based on Mobile Menu v1.0 by George Lieu, 2015, licensed under MIT
**/

;(function($) {
	'use strict';
	$.fn.mobileMenu = function(options) {
		var defaults = {
			menuwidth    : 250,
			slidespeed   : 300,
			windowswidth : 767,
			
			bodyslide    : false,
			animation    : true,
			autocollapse : false,
			
			classmenu          : "mm_offcanvas",
			classmenuactive    : "mm--expand",
			classmenuhidden    : "mm--collapse",
			classtoggle        : "mm_toggle",
			classclose         : "mm_close",
			classoverlay       : "mm_overlay",
			classoverlayactive : "mm_overlay--visible",
			classbody          : "mm_body--visible",
			classbutton        : "mm_button",
			classbuttonhide    : "mm_button__minus",
			classbuttonshow    : "mm_button__plus",
			classbuttonopen    : "mm_button--open",
			classlinkactive    : "active"
		};
		
		return this.each(function() {
			var config = $.extend({}, defaults, options);
			var self = $(this),
				overlay = $('<div class="'+config.classoverlay+'"></div>'),
				close = $('.'+config.classclose),
				body = $('body'),
				isOpen = false;
			
			mmInit();
			
			$('.'+config.classtoggle).click(function() {
				!isOpen ? mmOpen() : mmClose();
			});
			
			function mmInit() {
				overlay.appendTo(body);
				self.appendTo(body);
				self.addClass(config.classmenuhidden);
				mmAnimate('init');
				//self.find('ul:first').addClass(config.classmenu);
				self.css('width', config.menuwidth);
				self.find('.'+config.classmenu+' ul').css('display', 'none');
				var expandLink = '<span class=\"'+config.classbutton+' '+config.classbuttonshow+'\"></span>';
				self.find('li ul').parent().prepend( expandLink );
			}
			
			function mmAnimate(s) {
				if (config.animation) {
					if (s === 'open') {
						self.animate((config.animation === 'right') ? { right: '0' } : { left: '0' }, config.slidespeed, 'linear', null);
						if (config.bodyslide == true) {
							body.animate({ left: (config.animation === 'right') ? -(config.menuwidth) : config.menuwidth }, config.slidespeed, 'linear').css('overflow-y', 'hidden');
						}
					} else if (s === 'close') {
						self.animate((config.animation === 'right') ? { right: -(config.menuwidth) } : { left: -(config.menuwidth) }, config.slidespeed, 'linear', null);
						if (config.bodyslide == true) {
							body.animate({ left: "0" }, config.slidespeed, 'linear').css('overflow-y', 'auto');
						}
					} else if (s === 'init') {
						self.css((config.animation === 'right') ? {'right': -(config.menuwidth), 'left': 'auto'} : {'left': -(config.menuwidth), 'right': 'auto'});
						if (config.bodyslide == true) {
							body.css({'position': 'relative', 'left': 0, 'overflow-y': 'auto'});
						}
					}
				}
			}
			
			function mmOpen() {
				body.addClass(config.classbody);
				overlay.addClass(config.classoverlayactive);
				self.addClass(config.classmenuactive);
				self.removeClass(config.classmenuhidden);
				mmAnimate('open');
				isOpen = true;
			}
			
			function mmClose() {
				mmAnimate('close');
				self.removeClass(config.classmenuactive);
				self.addClass(config.classmenuhidden);
				body.removeClass(config.classbody);
				overlay.removeClass(config.classoverlayactive);
				isOpen = false;
			}
			
			$(window).resize(function() {
				if ($(window).width() >= config.windowswidth && isOpen) {
					if (self.css('left') != -(config.menuwidth)) {
						mmClose();
					}
				}
			});
			
			// multilevel menu
			
			$('.'+config.classmenu+' li span.'+config.classbutton).click(function() {
				
				if (config.autocollapse == true) {
					$(this).nextAll('ul').find('li span').each(function(){
						if ($(this).hasClass(config.classbuttonopen)) {
							
							$(this).nextAll('ul').slideToggle(function(){
								if (config.autocollapse == true) {
									$(this).promise().done();
								}
							});
							
							if ($(this).hasClass(config.classbuttonopen)) {
								$(this).removeClass(config.classbuttonhide).addClass(config.classbuttonshow);
							} else {
								$(this).removeClass(config.classbuttonshow).addClass(config.classbuttonhide);
							}
							$(this).removeClass(config.classbuttonopen);
							
						}
					});
				}
				
				$(this).nextAll('ul').slideToggle(function(){
					if (config.autocollapse == true) {
						$(this).promise().done();
					}
				});
				
				if ($(this).hasClass(config.classbuttonshow)) {
					$(this).removeClass(config.classbuttonshow).addClass(config.classbuttonhide);
				} else {
					$(this).removeClass(config.classbuttonhide).addClass(config.classbuttonshow);
				}
				$(this).toggleClass(config.classbuttonopen);
				
			});
			
			$('.'+config.classmenu+' li a').click(function() {
				$('.'+config.classmenu+' li a').removeClass(config.classlinkactive);
				$(this).addClass(config.classlinkactive);
				mmClose();
			});
			
			overlay.click(function() {
				mmClose();
			});
			
			close.click(function() {
				mmClose();
			});
			
			$('.'+config.classmenu+' li a.'+config.classlinkactive).parent().children('.'+config.classbutton).removeClass(config.classbuttonshow).addClass(config.classbuttonhide+' '+config.classbuttonopen);
			$('.'+config.classmenu+' li a.'+config.classlinkactive).parent().children('ul').css('display', 'block');
			
		});
	};
})(jQuery);